const cfg = window.AUTOCAD_PORTFOLIO_CONFIG || {};

const categories = [
  "All",
  "2D Drafting",
  "3D Modeling",
  "Mechanical Design",
  "Architectural Design",
  "Product Design",
  "Technical Drawing",
];

const FALLBACK_SOFTWARE = [
  { id: "fallback-autocad", name: "AutoCAD", initials: "AC", note: "CAD drawings & modeling", published: true, sort_order: 0 },
];

const FALLBACK_PROJECTS = [
  {
    id: "sample-machine-frame",
    title: "Precision Machine Frame",
    description: "Sample concept demonstrating a structured machine-frame presentation with a clean 3D-focused workflow.",
    category: "3D Modeling",
    project_date: null,
    image_url: "./assets/projects/01-machine-frame.png",
    gallery_urls: ["./assets/projects/01-machine-frame.png"],
    software_used: ["AutoCAD"],
    model_url: "./assets/models/innovelous-cad-model-upright.glb",
    published: true,
    sort_order: 0,
    is_sample: true,
  },
  {
    id: "sample-mechanical-assembly",
    title: "Mechanical Assembly",
    description: "Sample exploded assembly study focused on component relationships, alignment, and mechanical detailing.",
    category: "Mechanical Design",
    project_date: null,
    image_url: "./assets/projects/02-mechanical-assembly.png",
    gallery_urls: ["./assets/projects/02-mechanical-assembly.png"],
    software_used: ["AutoCAD"],
    published: true,
    sort_order: 1,
    is_sample: true,
  },
  {
    id: "sample-floor-plan",
    title: "Residential Floor Plan",
    description: "Sample 2D planning sheet showing room zoning, openings, dimensions, and a clear drafting hierarchy.",
    category: "2D Drafting",
    project_date: null,
    image_url: "./assets/projects/03-floor-plan.png",
    gallery_urls: ["./assets/projects/03-floor-plan.png"],
    software_used: ["AutoCAD"],
    published: true,
    sort_order: 2,
    is_sample: true,
  },
  {
    id: "sample-architectural-massing",
    title: "Architectural Massing Study",
    description: "Sample architectural concept exploring primary volumes, proportions, and a restrained visualization language.",
    category: "Architectural Design",
    project_date: null,
    image_url: "./assets/projects/04-architectural-massing.png",
    gallery_urls: ["./assets/projects/04-architectural-massing.png"],
    software_used: ["AutoCAD"],
    published: true,
    sort_order: 3,
    is_sample: true,
  },
  {
    id: "sample-enclosure",
    title: "Electronics Enclosure",
    description: "Sample product-design study for a compact electronics housing with clean geometry and fabrication-aware detailing.",
    category: "Product Design",
    project_date: null,
    image_url: "./assets/projects/05-product-enclosure.png",
    gallery_urls: ["./assets/projects/05-product-enclosure.png"],
    software_used: ["AutoCAD"],
    published: true,
    sort_order: 4,
    is_sample: true,
  },
  {
    id: "sample-fabrication-drawing",
    title: "Fabrication Drawing Set",
    description: "Sample technical sheet presenting orthographic views, detail callouts, and dimensional communication for fabrication.",
    category: "Technical Drawing",
    project_date: null,
    image_url: "./assets/projects/06-fabrication-drawing.png",
    gallery_urls: ["./assets/projects/06-fabrication-drawing.png"],
    software_used: ["AutoCAD"],
    published: true,
    sort_order: 5,
    is_sample: true,
  },
];

const el = (id) => document.getElementById(id);
const escapeHtml = (value = "") => String(value).replace(/[&<>'"]/g, (char) => ({
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  "'": "&#39;",
  '"': "&quot;",
}[char]));

const appState = {
  supabase: null,
  session: null,
  projects: [],
  software: [],
  ownerProjects: [],
  ownerSoftware: [],
  activeCategory: "All",
  activeProject: null,
  activeImageIndex: 0,
  projectShowingModel: false,
};

function configureContactLinks() {
  const href = cfg.contactHref || "https://innovelous.com/";
  const whatsappHref = cfg.whatsappHref || "https://wa.me/923329250936";
  document.querySelectorAll(".contact-link").forEach((link) => link.setAttribute("href", href));
  document.querySelectorAll(".whatsapp-link").forEach((link) => link.setAttribute("href", whatsappHref));
}

function initRevealAnimations() {
  const items = document.querySelectorAll(".reveal");
  items.forEach((node) => {
    const delay = node.dataset.revealDelay;
    if (delay) node.style.setProperty("--reveal-delay", `${delay}ms`);
  });

  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    items.forEach((node) => node.classList.add("is-visible"));
    return;
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.08, rootMargin: "0px 0px -4%" });

  items.forEach((node) => observer.observe(node));
}

function initDialogs() {
  document.querySelectorAll("[data-close-dialog]").forEach((button) => {
    button.addEventListener("click", () => el(button.dataset.closeDialog)?.close());
  });

  document.querySelectorAll("dialog").forEach((dialog) => {
    dialog.addEventListener("click", (event) => {
      if (event.target === dialog) dialog.close();
    });
  });

  el("projectDialog").addEventListener("close", () => {
    const model = el("projectDialogModel");
    model.removeAttribute("src");
    model.hidden = true;
    el("projectImageStage").hidden = false;
    appState.projectShowingModel = false;
  });
}

function initModelViewer() {
  const viewer = el("cadViewer");
  const progressBar = el("progressBar");
  const progressText = el("progressText");
  const viewerState = el("viewerState");
  const errorPanel = el("modelError");
  const rotateButton = el("toggleRotation");

  if (cfg.modelPath) viewer.src = cfg.modelPath;
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    viewer.autoRotate = false;
    rotateButton.setAttribute("aria-pressed", "false");
    rotateButton.setAttribute("aria-label", "Resume model rotation");
    rotateButton.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg>';
  }

  viewer.addEventListener("progress", (event) => {
    const amount = Math.max(0, Math.min(1, event.detail?.totalProgress ?? 0));
    const pct = Math.round(amount * 100);
    progressBar.style.width = `${pct}%`;
    progressText.textContent = `Loading 3D model · ${pct}%`;
    viewerState.textContent = pct < 100 ? `Loading ${pct}%` : "Rendering";
  });

  viewer.addEventListener("load", () => {
    viewerState.textContent = "Interactive";
    errorPanel.hidden = true;
  });

  viewer.addEventListener("error", () => {
    viewerState.textContent = "Load error";
    errorPanel.hidden = false;
  });

  rotateButton.addEventListener("click", () => {
    const shouldRotate = !viewer.autoRotate;
    viewer.autoRotate = shouldRotate;
    rotateButton.setAttribute("aria-pressed", String(shouldRotate));
    rotateButton.setAttribute("aria-label", shouldRotate ? "Pause model rotation" : "Resume model rotation");
    rotateButton.title = shouldRotate ? "Pause rotation" : "Resume rotation";
    rotateButton.innerHTML = shouldRotate
      ? '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5h3v14H8zM13 5h3v14h-3z"/></svg>'
      : '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg>';
  });

  el("resetCamera").addEventListener("click", () => {
    // Preserve the corrected upright model orientation. Reset only viewer orbit/target.
    viewer.cameraOrbit = "35deg 72deg 125%";
    viewer.cameraTarget = "0m 0.4105m 0m";
    viewer.fieldOfView = "30deg";
    viewer.jumpCameraToGoal?.();
    window.setTimeout(() => viewer.resetTurntableRotation?.(), 40);
  });

  el("fullscreenViewer").addEventListener("click", async () => {
    const frame = el("viewerFrame");
    try {
      if (!document.fullscreenElement) await frame.requestFullscreen();
      else await document.exitFullscreen();
    } catch (error) {
      console.warn("Fullscreen unavailable", error);
    }
  });

  el("retryModel").addEventListener("click", () => {
    errorPanel.hidden = true;
    viewerState.textContent = "Retrying";
    const src = viewer.src;
    viewer.removeAttribute("src");
    requestAnimationFrame(() => { viewer.src = src; });
  });

  window.setTimeout(() => {
    if (!customElements.get("model-viewer")) {
      viewerState.textContent = "Viewer unavailable";
      errorPanel.hidden = false;
    }
  }, 8000);
}

function renderFilters() {
  const host = el("portfolioFilters");
  const available = new Set(appState.projects.map((project) => project.category).filter(Boolean));
  const visibleCategories = ["All", ...categories.slice(1).filter((category) => available.has(category))];

  if (visibleCategories.length <= 1) {
    host.innerHTML = "";
    return;
  }

  host.innerHTML = visibleCategories.map((category) => `
    <button class="filter-button ${category === appState.activeCategory ? "is-active" : ""}" type="button" data-category="${escapeHtml(category)}">${escapeHtml(category)}</button>
  `).join("");

  host.querySelectorAll("[data-category]").forEach((button) => {
    button.addEventListener("click", () => {
      appState.activeCategory = button.dataset.category;
      renderFilters();
      renderProjects();
    });
  });
}

function formatProjectDate(value) {
  if (!value) return "";
  const date = new Date(`${value}T12:00:00`);
  if (Number.isNaN(date.getTime())) return "";
  return new Intl.DateTimeFormat("en", { year: "numeric", month: "short" }).format(date);
}

function projectImages(project) {
  const items = Array.isArray(project.gallery_urls) ? project.gallery_urls.filter(Boolean) : [];
  if (project.image_url && !items.includes(project.image_url)) items.unshift(project.image_url);
  return [...new Set(items)];
}

function projectSoftware(project) {
  if (Array.isArray(project.software_used)) return project.software_used.filter(Boolean);
  if (typeof project.software_used === "string") return project.software_used.split(",").map((x) => x.trim()).filter(Boolean);
  return [];
}

function renderProjects() {
  const grid = el("portfolioGrid");
  const empty = el("portfolioEmpty");
  const filtered = appState.activeCategory === "All"
    ? appState.projects
    : appState.projects.filter((project) => project.category === appState.activeCategory);

  grid.innerHTML = filtered.map((project, index) => {
    const images = projectImages(project);
    const cover = images[0] || project.image_url || "";
    return `
      <article class="project-card" tabindex="0" role="button" aria-label="View ${escapeHtml(project.title)}" data-project-id="${escapeHtml(project.id)}">
        <div class="project-image">
          ${cover ? `<img src="${escapeHtml(cover)}" alt="${escapeHtml(project.title)}" loading="lazy" decoding="async" />` : `<div class="project-image-placeholder" aria-hidden="true"><span>PROJECT IMAGE</span></div>`}
          <span class="project-number" aria-hidden="true">${String(index + 1).padStart(2, "0")}</span>
        </div>
        <div class="project-card-content">
          <div class="project-kicker">
            <span class="project-category-pill">${project.is_sample ? "SAMPLE" : "CAD"} <span aria-hidden="true">→</span> ${escapeHtml(project.category || "Project")}</span>
            <span class="project-date">${escapeHtml(formatProjectDate(project.project_date))}</span>
          </div>
          <div class="project-title-row">
            <h3>${escapeHtml(project.title)}</h3>
            <span class="project-arrow" aria-hidden="true">↗</span>
          </div>
          <p>${escapeHtml(project.description)}</p>
          <span class="project-view">View project <span aria-hidden="true">↗</span></span>
        </div>
      </article>
    `;
  }).join("");

  empty.hidden = filtered.length > 0;
  grid.querySelectorAll("[data-project-id]").forEach((card) => {
    const open = () => openProjectDialog(card.dataset.projectId);
    card.addEventListener("click", open);
    card.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        open();
      }
    });
  });
}

function showProjectImage(index) {
  const project = appState.activeProject;
  if (!project) return;
  const images = projectImages(project);
  if (!images.length) return;
  const safeIndex = Math.max(0, Math.min(index, images.length - 1));
  appState.activeImageIndex = safeIndex;
  appState.projectShowingModel = false;

  const image = el("projectDialogImage");
  image.src = images[safeIndex];
  image.alt = `${project.title}${images.length > 1 ? ` — image ${safeIndex + 1}` : ""}`;
  el("projectImageStage").hidden = false;
  el("projectDialogModel").hidden = true;

  const toggle = el("projectModelToggle");
  if (project.model_url) toggle.textContent = "View 3D model";

  el("projectDialogThumbs").querySelectorAll("[data-image-index]").forEach((button) => {
    button.classList.toggle("is-active", Number(button.dataset.imageIndex) === safeIndex);
  });
}

function toggleProjectModel() {
  const project = appState.activeProject;
  if (!project?.model_url) return;
  const model = el("projectDialogModel");
  const imageStage = el("projectImageStage");
  const toggle = el("projectModelToggle");

  appState.projectShowingModel = !appState.projectShowingModel;
  if (appState.projectShowingModel) {
    if (!model.src) model.src = project.model_url;
    model.hidden = false;
    imageStage.hidden = true;
    toggle.textContent = "View images";
  } else {
    model.hidden = true;
    imageStage.hidden = false;
    toggle.textContent = "View 3D model";
  }
}

function openProjectDialog(projectId) {
  const project = appState.projects.find((item) => String(item.id) === String(projectId));
  if (!project) return;
  appState.activeProject = project;
  appState.activeImageIndex = 0;
  appState.projectShowingModel = false;

  el("projectDialogCategory").textContent = project.category || "Project";
  el("projectDialogDate").textContent = formatProjectDate(project.project_date);
  el("projectDialogDate").dateTime = project.project_date || "";
  el("projectDialogTitle").textContent = project.title || "Untitled project";
  el("projectDialogDescription").textContent = project.description || "";

  const images = projectImages(project);
  el("projectDialogThumbs").innerHTML = images.map((url, index) => `
    <button class="detail-thumb ${index === 0 ? "is-active" : ""}" type="button" data-image-index="${index}" aria-label="Show project image ${index + 1}">
      <img src="${escapeHtml(url)}" alt="" loading="lazy" />
    </button>
  `).join("");
  el("projectDialogThumbs").querySelectorAll("[data-image-index]").forEach((button) => {
    button.addEventListener("click", () => showProjectImage(Number(button.dataset.imageIndex)));
  });

  const modelToggle = el("projectModelToggle");
  modelToggle.hidden = !project.model_url;
  modelToggle.textContent = "View 3D model";
  el("projectDialogModel").removeAttribute("src");
  el("projectDialogModel").hidden = true;
  el("projectImageStage").hidden = false;

  if (images.length) showProjectImage(0);
  else {
    el("projectDialogImage").removeAttribute("src");
    el("projectDialogImage").alt = "";
  }

  const software = projectSoftware(project);
  el("projectDialogSoftware").hidden = software.length === 0;
  el("projectDialogSoftwareTags").innerHTML = software.map((name) => `<span>${escapeHtml(name)}</span>`).join("");

  el("projectDialog").showModal();
}

function renderSoftware() {
  const host = el("softwareGrid");
  const metadataItems = appState.software.length
    ? appState.software
    : (appState.supabase ? [] : FALLBACK_SOFTWARE);
  const metadata = new Map(metadataItems.map((item) => [String(item.name || "").trim().toLowerCase(), item]));
  const usage = new Map();

  appState.projects.forEach((project) => {
    projectSoftware(project).forEach((name) => {
      const cleanName = String(name || "").trim();
      if (!cleanName) return;
      const key = cleanName.toLowerCase();
      const current = usage.get(key) || { name: cleanName, count: 0 };
      current.count += 1;
      usage.set(key, current);
    });
  });

  const items = [...usage.entries()].map(([key, item]) => ({
    ...item,
    ...(metadata.get(key) || {}),
    name: item.name,
    count: item.count,
  }));

  if (!items.length) {
    host.innerHTML = '<div class="software-empty">Tools will appear here automatically when they are assigned to a published project.</div>';
    return;
  }

  host.innerHTML = items.map((item, index) => `
    <article class="software-card">
      <span class="software-index">${String(index + 1).padStart(2, "0")}</span>
      <span class="software-code">${escapeHtml(item.initials || String(item.name || "").slice(0, 2).toUpperCase())}</span>
      <div class="software-copy">
        <h3>${escapeHtml(item.name)}</h3>
        ${item.note ? `<p>${escapeHtml(item.note)}</p>` : '<p>Used in published CAD work</p>'}
      </div>
      <span class="software-count">${item.count} ${item.count === 1 ? "PROJECT" : "PROJECTS"}</span>
    </article>
  `).join("");
}

function isSupabaseConfigured() {
  return Boolean(cfg.supabaseUrl && cfg.supabaseAnonKey && window.supabase?.createClient);
}

async function initSupabase() {
  if (!isSupabaseConfigured()) {
    el("backendNotice").hidden = false;
    appState.projects = FALLBACK_PROJECTS;
    renderFilters();
    renderProjects();
    renderSoftware();
    return;
  }

  appState.supabase = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey, {
    auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
  });

  const { data } = await appState.supabase.auth.getSession();
  appState.session = data.session;
  updateOwnerAuthView();

  appState.supabase.auth.onAuthStateChange((_event, session) => {
    appState.session = session;
    updateOwnerAuthView();
    if (session) loadOwnerData().catch(console.error);
  });

  await Promise.all([loadPublicProjects(), loadPublicSoftware()]);
  if (appState.session) await loadOwnerData();
}

async function loadPublicProjects() {
  if (!appState.supabase) return;
  const { data, error } = await appState.supabase
    .from("cad_projects")
    .select("*")
    .eq("published", true)
    .order("sort_order", { ascending: true })
    .order("created_at", { ascending: false });
  if (error) {
    console.warn("Could not load projects", error.message);
    appState.projects = FALLBACK_PROJECTS;
  } else {
    appState.projects = (data && data.length) ? data : FALLBACK_PROJECTS;
  }
  if (appState.activeCategory !== "All" && !appState.projects.some((p) => p.category === appState.activeCategory)) appState.activeCategory = "All";
  renderFilters();
  renderProjects();
  renderSoftware();
}

async function loadPublicSoftware() {
  if (!appState.supabase) return;
  const { data, error } = await appState.supabase
    .from("cad_software")
    .select("*")
    .eq("published", true)
    .order("sort_order", { ascending: true });
  if (error) {
    console.warn("Could not load software list. Run the latest supabase-schema.sql if needed.", error.message);
    appState.software = [];
  } else {
    appState.software = data || [];
  }
  renderSoftware();
}

function setMessage(node, text, type = "") {
  node.textContent = text;
  node.className = `form-message${type ? ` ${type}` : ""}`;
}

function updateOwnerAuthView() {
  const authenticated = Boolean(appState.session);
  el("ownerAuthView").hidden = authenticated;
  el("ownerDashboard").hidden = !authenticated;
  if (authenticated) loadOwnerData().catch(console.error);
}

function initOwnerAccess() {
  const ownerDialog = el("ownerDialog");
  const params = new URLSearchParams(location.search);
  if (params.get("owner") === "1") window.setTimeout(() => ownerDialog.showModal(), 180);

  window.addEventListener("keydown", (event) => {
    if (event.altKey && event.shiftKey && event.key.toLowerCase() === "a") {
      event.preventDefault();
      if (!ownerDialog.open) ownerDialog.showModal();
    }
  });

  el("ownerLoginForm").addEventListener("submit", ownerSignIn);
  el("ownerSignOut").addEventListener("click", ownerSignOut);
  el("projectForm").addEventListener("submit", saveProject);
  el("projectCancelEdit").addEventListener("click", () => resetProjectForm());
  el("softwareForm").addEventListener("submit", saveSoftware);
  el("softwareCancelEdit").addEventListener("click", () => resetSoftwareForm());
  el("projectModelToggle").addEventListener("click", toggleProjectModel);

  document.querySelectorAll("[data-owner-tab]").forEach((button) => {
    button.addEventListener("click", () => switchOwnerTab(button.dataset.ownerTab));
  });
}

function switchOwnerTab(name) {
  document.querySelectorAll("[data-owner-tab]").forEach((button) => {
    const active = button.dataset.ownerTab === name;
    button.classList.toggle("is-active", active);
    button.setAttribute("aria-selected", String(active));
  });
  document.querySelectorAll("[data-owner-panel]").forEach((panel) => {
    const active = panel.dataset.ownerPanel === name;
    panel.classList.toggle("is-active", active);
    panel.hidden = !active;
  });
}

async function ownerSignIn(event) {
  event.preventDefault();
  const msg = el("authMessage");
  if (!appState.supabase) return setMessage(msg, "Supabase is not configured.", "error");
  setMessage(msg, "Signing in…");
  const { error } = await appState.supabase.auth.signInWithPassword({
    email: el("ownerEmail").value.trim(),
    password: el("ownerPassword").value,
  });
  if (error) setMessage(msg, error.message, "error");
  else setMessage(msg, "Signed in.", "success");
}

async function ownerSignOut() {
  if (!appState.supabase) return;
  await appState.supabase.auth.signOut();
  appState.ownerProjects = [];
  appState.ownerSoftware = [];
}

async function loadOwnerData() {
  if (!appState.supabase || !appState.session) return;
  const [projectsResult, softwareResult] = await Promise.all([
    appState.supabase.from("cad_projects").select("*").order("sort_order", { ascending: true }).order("created_at", { ascending: false }),
    appState.supabase.from("cad_software").select("*").order("sort_order", { ascending: true }),
  ]);

  if (projectsResult.error) console.warn(projectsResult.error.message);
  else appState.ownerProjects = projectsResult.data || [];

  if (softwareResult.error) console.warn(softwareResult.error.message);
  else appState.ownerSoftware = softwareResult.data || [];

  renderOwnerProjectList();
  renderOwnerSoftwareList();
}

function imageLooksSafe(file) {
  const allowed = new Set(["image/png", "image/jpeg", "image/webp", "image/avif"]);
  const max = Number(cfg.maxUploadBytes || 8 * 1024 * 1024);
  return allowed.has(file.type) && file.size > 0 && file.size <= max;
}

function modelLooksSafe(file) {
  const max = Number(cfg.maxModelUploadBytes || 50 * 1024 * 1024);
  return file && file.size > 0 && file.size <= max && file.name.toLowerCase().endsWith(".glb");
}

function safeFilename(name) {
  const parts = String(name).toLowerCase().split(".");
  const ext = parts.length > 1 ? `.${parts.pop().replace(/[^a-z0-9]/g, "")}` : "";
  const base = parts.join(".").replace(/[^a-z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60) || "file";
  return `${base}${ext}`;
}

async function uploadProjectImages(files) {
  if (!files.length) return { paths: [], urls: [] };
  if (files.length > 6) throw new Error("Upload up to 6 project images.");
  files.forEach((file) => {
    if (!imageLooksSafe(file)) throw new Error(`Unsupported or oversized image: ${file.name}`);
  });

  const userId = appState.session?.user?.id;
  if (!userId) throw new Error("Owner session expired.");

  const paths = [];
  const urls = [];
  for (let i = 0; i < files.length; i += 1) {
    const file = files[i];
    const path = `${userId}/${Date.now()}-${i}-${safeFilename(file.name)}`;
    const { error } = await appState.supabase.storage.from("cad-portfolio").upload(path, file, {
      cacheControl: "31536000",
      upsert: false,
      contentType: file.type,
    });
    if (error) throw error;
    const { data } = appState.supabase.storage.from("cad-portfolio").getPublicUrl(path);
    paths.push(path);
    urls.push(data.publicUrl);
  }
  return { paths, urls };
}

async function uploadProjectModel(file) {
  if (!modelLooksSafe(file)) throw new Error("Use a valid .glb file up to 50 MB.");
  const userId = appState.session?.user?.id;
  if (!userId) throw new Error("Owner session expired.");
  const path = `${userId}/${Date.now()}-${safeFilename(file.name)}`;
  const { error } = await appState.supabase.storage.from("cad-models").upload(path, file, {
    cacheControl: "31536000",
    upsert: false,
    contentType: "model/gltf-binary",
  });
  if (error) throw error;
  const { data } = appState.supabase.storage.from("cad-models").getPublicUrl(path);
  return { path, url: data.publicUrl };
}

function parseSoftwareInput(value) {
  return [...new Set(String(value || "").split(",").map((item) => item.trim()).filter(Boolean))].slice(0, 12);
}

async function saveProject(event) {
  event.preventDefault();
  const msg = el("projectFormMessage");
  if (!appState.supabase) return setMessage(msg, "Supabase is not configured.", "error");

  const id = el("projectId").value;
  const current = appState.ownerProjects.find((item) => String(item.id) === String(id));
  const imageFiles = Array.from(el("projectImages").files || []);
  const modelFile = el("projectModel").files?.[0] || null;
  let newImages = null;
  let newModel = null;
  setMessage(msg, "Saving…");

  try {
    if (!id && imageFiles.length === 0) throw new Error("Add at least one project image.");
    if (imageFiles.length) newImages = await uploadProjectImages(imageFiles);
    if (modelFile) newModel = await uploadProjectModel(modelFile);

    const existingImages = projectImages(current || {});
    const existingPaths = Array.isArray(current?.gallery_paths) && current.gallery_paths.length
      ? current.gallery_paths
      : (current?.image_path ? [current.image_path] : []);

    const payload = {
      title: el("projectTitle").value.trim(),
      description: el("projectDescription").value.trim(),
      category: el("projectCategory").value,
      project_date: el("projectDate").value || null,
      software_used: parseSoftwareInput(el("projectSoftware").value),
      published: el("projectPublished").checked,
      updated_at: new Date().toISOString(),
    };

    if (newImages) {
      payload.image_url = newImages.urls[0];
      payload.image_path = newImages.paths[0];
      payload.gallery_urls = newImages.urls;
      payload.gallery_paths = newImages.paths;
    } else if (id && existingImages.length) {
      payload.gallery_urls = existingImages;
      payload.gallery_paths = existingPaths;
    }

    if (newModel) {
      payload.model_url = newModel.url;
      payload.model_path = newModel.path;
    }

    if (!id) payload.sort_order = appState.ownerProjects.length;

    const result = id
      ? await appState.supabase.from("cad_projects").update(payload).eq("id", id)
      : await appState.supabase.from("cad_projects").insert(payload);
    if (result.error) throw result.error;

    if (newImages && existingPaths.length) {
      await appState.supabase.storage.from("cad-portfolio").remove([...new Set(existingPaths)]);
    }
    if (newModel && current?.model_path) {
      await appState.supabase.storage.from("cad-models").remove([current.model_path]);
    }

    setMessage(msg, id ? "Project updated." : "Project added.", "success");
    resetProjectForm(false);
    await Promise.all([loadOwnerData(), loadPublicProjects()]);
  } catch (error) {
    if (newImages?.paths?.length) await appState.supabase.storage.from("cad-portfolio").remove(newImages.paths);
    if (newModel?.path) await appState.supabase.storage.from("cad-models").remove([newModel.path]);
    setMessage(msg, error.message || "Could not save project.", "error");
  }
}

function resetProjectForm(clearMessage = true) {
  el("projectForm").reset();
  el("projectId").value = "";
  el("projectPublished").checked = true;
  el("projectSubmit").textContent = "Add project";
  el("projectCancelEdit").hidden = true;
  if (clearMessage) setMessage(el("projectFormMessage"), "");
}

function editProject(id) {
  const item = appState.ownerProjects.find((project) => String(project.id) === String(id));
  if (!item) return;
  el("projectId").value = item.id;
  el("projectTitle").value = item.title || "";
  el("projectDescription").value = item.description || "";
  el("projectCategory").value = item.category || "3D Modeling";
  el("projectDate").value = item.project_date || "";
  el("projectSoftware").value = projectSoftware(item).join(", ");
  el("projectPublished").checked = Boolean(item.published);
  el("projectSubmit").textContent = "Update project";
  el("projectCancelEdit").hidden = false;
  setMessage(el("projectFormMessage"), "Existing images/model stay unchanged unless new files are selected.");
  el("projectForm").scrollIntoView({ behavior: "smooth", block: "start" });
}

async function deleteProject(id) {
  const item = appState.ownerProjects.find((project) => String(project.id) === String(id));
  if (!item || !confirm(`Delete “${item.title}”?`)) return;
  const { error } = await appState.supabase.from("cad_projects").delete().eq("id", id);
  if (error) return alert(error.message);

  const imagePaths = Array.isArray(item.gallery_paths) && item.gallery_paths.length ? item.gallery_paths : (item.image_path ? [item.image_path] : []);
  if (imagePaths.length) await appState.supabase.storage.from("cad-portfolio").remove([...new Set(imagePaths)]);
  if (item.model_path) await appState.supabase.storage.from("cad-models").remove([item.model_path]);
  await Promise.all([loadOwnerData(), loadPublicProjects()]);
}

async function moveProject(id, direction) {
  const list = [...appState.ownerProjects];
  const index = list.findIndex((item) => String(item.id) === String(id));
  const swapIndex = index + direction;
  if (index < 0 || swapIndex < 0 || swapIndex >= list.length) return;
  [list[index], list[swapIndex]] = [list[swapIndex], list[index]];

  for (let sortOrder = 0; sortOrder < list.length; sortOrder += 1) {
    const { error } = await appState.supabase.from("cad_projects").update({ sort_order: sortOrder }).eq("id", list[sortOrder].id);
    if (error) return alert(error.message);
  }
  await Promise.all([loadOwnerData(), loadPublicProjects()]);
}

function renderOwnerProjectList() {
  const host = el("ownerProjectList");
  if (!appState.ownerProjects.length) {
    host.innerHTML = '<div class="backend-notice">No projects yet. Add only real work you want published.</div>';
    return;
  }

  host.innerHTML = appState.ownerProjects.map((item, index) => {
    const cover = projectImages(item)[0] || "";
    return `
      <div class="admin-item">
        ${cover ? `<img class="admin-item-thumb" src="${escapeHtml(cover)}" alt="" loading="lazy">` : '<div class="admin-item-thumb admin-item-noimage">IMG</div>'}
        <div class="admin-item-main"><strong>${escapeHtml(item.title)}</strong><span>${escapeHtml(item.category)} · ${item.published ? "Published" : "Draft"}${item.model_url ? " · 3D" : ""}</span></div>
        <div class="admin-item-actions">
          <button class="admin-action" type="button" data-project-move="-1" data-id="${escapeHtml(item.id)}" ${index === 0 ? "disabled" : ""} aria-label="Move project up">↑</button>
          <button class="admin-action" type="button" data-project-move="1" data-id="${escapeHtml(item.id)}" ${index === appState.ownerProjects.length - 1 ? "disabled" : ""} aria-label="Move project down">↓</button>
          <button class="admin-action" type="button" data-project-edit="${escapeHtml(item.id)}">Edit</button>
          <button class="admin-action danger" type="button" data-project-delete="${escapeHtml(item.id)}">Delete</button>
        </div>
      </div>
    `;
  }).join("");

  host.querySelectorAll("[data-project-edit]").forEach((button) => button.addEventListener("click", () => editProject(button.dataset.projectEdit)));
  host.querySelectorAll("[data-project-delete]").forEach((button) => button.addEventListener("click", () => deleteProject(button.dataset.projectDelete)));
  host.querySelectorAll("[data-project-move]").forEach((button) => button.addEventListener("click", () => moveProject(button.dataset.id, Number(button.dataset.projectMove))));
}

async function saveSoftware(event) {
  event.preventDefault();
  const msg = el("softwareFormMessage");
  if (!appState.supabase) return setMessage(msg, "Supabase is not configured.", "error");
  const id = el("softwareId").value;
  const payload = {
    name: el("softwareName").value.trim(),
    initials: el("softwareInitials").value.trim().toUpperCase() || null,
    note: el("softwareNote").value.trim() || null,
    published: el("softwarePublished").checked,
    updated_at: new Date().toISOString(),
  };
  if (!id) payload.sort_order = appState.ownerSoftware.length;
  setMessage(msg, "Saving…");
  const result = id
    ? await appState.supabase.from("cad_software").update(payload).eq("id", id)
    : await appState.supabase.from("cad_software").insert(payload);
  if (result.error) return setMessage(msg, result.error.message, "error");
  setMessage(msg, id ? "Software updated." : "Software added.", "success");
  resetSoftwareForm(false);
  await Promise.all([loadOwnerData(), loadPublicSoftware()]);
}

function resetSoftwareForm(clearMessage = true) {
  el("softwareForm").reset();
  el("softwareId").value = "";
  el("softwarePublished").checked = true;
  el("softwareSubmit").textContent = "Add software";
  el("softwareCancelEdit").hidden = true;
  if (clearMessage) setMessage(el("softwareFormMessage"), "");
}

function editSoftware(id) {
  const item = appState.ownerSoftware.find((entry) => String(entry.id) === String(id));
  if (!item) return;
  el("softwareId").value = item.id;
  el("softwareName").value = item.name || "";
  el("softwareInitials").value = item.initials || "";
  el("softwareNote").value = item.note || "";
  el("softwarePublished").checked = Boolean(item.published);
  el("softwareSubmit").textContent = "Update software";
  el("softwareCancelEdit").hidden = false;
  el("softwareForm").scrollIntoView({ behavior: "smooth", block: "start" });
}

async function deleteSoftware(id) {
  const item = appState.ownerSoftware.find((entry) => String(entry.id) === String(id));
  if (!item || !confirm(`Delete “${item.name}” from the software list?`)) return;
  const { error } = await appState.supabase.from("cad_software").delete().eq("id", id);
  if (error) return alert(error.message);
  await Promise.all([loadOwnerData(), loadPublicSoftware()]);
}

async function moveSoftware(id, direction) {
  const list = [...appState.ownerSoftware];
  const index = list.findIndex((item) => String(item.id) === String(id));
  const swapIndex = index + direction;
  if (index < 0 || swapIndex < 0 || swapIndex >= list.length) return;
  [list[index], list[swapIndex]] = [list[swapIndex], list[index]];
  for (let sortOrder = 0; sortOrder < list.length; sortOrder += 1) {
    const { error } = await appState.supabase.from("cad_software").update({ sort_order: sortOrder }).eq("id", list[sortOrder].id);
    if (error) return alert(error.message);
  }
  await Promise.all([loadOwnerData(), loadPublicSoftware()]);
}

function renderOwnerSoftwareList() {
  const host = el("ownerSoftwareList");
  if (!appState.ownerSoftware.length) {
    host.innerHTML = '<div class="backend-notice">No software entries yet. Add only tools the team actually uses.</div>';
    return;
  }
  host.innerHTML = appState.ownerSoftware.map((item, index) => `
    <div class="admin-item">
      <div class="admin-item-thumb admin-item-noimage">${escapeHtml(item.initials || String(item.name).slice(0,2).toUpperCase())}</div>
      <div class="admin-item-main"><strong>${escapeHtml(item.name)}</strong><span>${escapeHtml(item.note || "No expertise note")} · ${item.published ? "Published" : "Draft"}</span></div>
      <div class="admin-item-actions">
        <button class="admin-action" type="button" data-software-move="-1" data-id="${escapeHtml(item.id)}" ${index === 0 ? "disabled" : ""} aria-label="Move software up">↑</button>
        <button class="admin-action" type="button" data-software-move="1" data-id="${escapeHtml(item.id)}" ${index === appState.ownerSoftware.length - 1 ? "disabled" : ""} aria-label="Move software down">↓</button>
        <button class="admin-action" type="button" data-software-edit="${escapeHtml(item.id)}">Edit</button>
        <button class="admin-action danger" type="button" data-software-delete="${escapeHtml(item.id)}">Delete</button>
      </div>
    </div>
  `).join("");
  host.querySelectorAll("[data-software-edit]").forEach((button) => button.addEventListener("click", () => editSoftware(button.dataset.softwareEdit)));
  host.querySelectorAll("[data-software-delete]").forEach((button) => button.addEventListener("click", () => deleteSoftware(button.dataset.softwareDelete)));
  host.querySelectorAll("[data-software-move]").forEach((button) => button.addEventListener("click", () => moveSoftware(button.dataset.id, Number(button.dataset.softwareMove))));
}

function init() {
  configureContactLinks();
  initRevealAnimations();
  initDialogs();
  initModelViewer();
  renderFilters();
  renderProjects();
  renderSoftware();
  initOwnerAccess();
  initSupabase().catch((error) => console.error("Portfolio initialization error", error));
}

document.addEventListener("DOMContentLoaded", init);
