-- Innovelous Technology CAD Portfolio — Supabase schema + RLS
-- Safe to run on a fresh project or over the earlier portfolio schema.
-- After creating the owner in Authentication > Users, add that user's UUID to owner_profiles.

create extension if not exists pgcrypto;

create table if not exists public.owner_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.owner_profiles enable row level security;

create or replace function public.is_owner()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.owner_profiles
    where user_id = auth.uid()
  );
$$;

revoke all on function public.is_owner() from public;
grant execute on function public.is_owner() to anon, authenticated;

drop policy if exists "Owner can read own owner profile" on public.owner_profiles;
create policy "Owner can read own owner profile"
on public.owner_profiles for select
to authenticated
using (user_id = auth.uid());

create table if not exists public.cad_projects (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 90),
  description text not null check (char_length(description) between 1 and 700),
  category text not null check (category in (
    '2D Drafting', '3D Modeling', 'Mechanical Design',
    'Architectural Design', 'Product Design', 'Technical Drawing'
  )),
  project_date date,
  image_url text not null,
  image_path text not null,
  published boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Additions used by the premium portfolio detail view. Existing projects continue to work.
alter table public.cad_projects add column if not exists gallery_urls text[] not null default '{}';
alter table public.cad_projects add column if not exists gallery_paths text[] not null default '{}';
alter table public.cad_projects add column if not exists software_used text[] not null default '{}';
alter table public.cad_projects add column if not exists model_url text;
alter table public.cad_projects add column if not exists model_path text;

-- If the table came from the older build, expand the description limit without deleting data.
do $$
begin
  if exists (
    select 1 from pg_constraint
    where conrelid = 'public.cad_projects'::regclass
      and contype = 'c'
      and pg_get_constraintdef(oid) ilike '%char_length(description)%500%'
  ) then
    execute (
      select 'alter table public.cad_projects drop constraint ' || quote_ident(conname)
      from pg_constraint
      where conrelid = 'public.cad_projects'::regclass
        and contype = 'c'
        and pg_get_constraintdef(oid) ilike '%char_length(description)%500%'
      limit 1
    );
  end if;
end $$;

alter table public.cad_projects drop constraint if exists cad_projects_description_length_check;
do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conrelid = 'public.cad_projects'::regclass
      and conname = 'cad_projects_description_length_premium_check'
  ) then
    alter table public.cad_projects
      add constraint cad_projects_description_length_premium_check
      check (char_length(description) between 1 and 700);
  end if;
end $$;

alter table public.cad_projects enable row level security;

drop policy if exists "Public can read published CAD projects" on public.cad_projects;
drop policy if exists "Owner can insert CAD projects" on public.cad_projects;
drop policy if exists "Owner can update CAD projects" on public.cad_projects;
drop policy if exists "Owner can delete CAD projects" on public.cad_projects;

create policy "Public can read published CAD projects"
on public.cad_projects for select
to anon, authenticated
using (published = true or public.is_owner());

create policy "Owner can insert CAD projects"
on public.cad_projects for insert
to authenticated
with check (public.is_owner());

create policy "Owner can update CAD projects"
on public.cad_projects for update
to authenticated
using (public.is_owner())
with check (public.is_owner());

create policy "Owner can delete CAD projects"
on public.cad_projects for delete
to authenticated
using (public.is_owner());

create table if not exists public.cad_software (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 70),
  initials text check (initials is null or char_length(initials) between 1 and 5),
  note text check (note is null or char_length(note) <= 120),
  published boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.cad_software enable row level security;

drop policy if exists "Public can read published CAD software" on public.cad_software;
drop policy if exists "Owner can insert CAD software" on public.cad_software;
drop policy if exists "Owner can update CAD software" on public.cad_software;
drop policy if exists "Owner can delete CAD software" on public.cad_software;

create policy "Public can read published CAD software"
on public.cad_software for select
to anon, authenticated
using (published = true or public.is_owner());

create policy "Owner can insert CAD software"
on public.cad_software for insert
to authenticated
with check (public.is_owner());

create policy "Owner can update CAD software"
on public.cad_software for update
to authenticated
using (public.is_owner())
with check (public.is_owner());

create policy "Owner can delete CAD software"
on public.cad_software for delete
to authenticated
using (public.is_owner());

-- Public image bucket with server-side MIME and size restrictions.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'cad-portfolio',
  'cad-portfolio',
  true,
  8388608,
  array['image/png','image/jpeg','image/webp','image/avif']
)
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

-- Separate GLB bucket so project models can be larger than images.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'cad-models',
  'cad-models',
  true,
  52428800,
  array['model/gltf-binary','application/octet-stream']
)
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

-- Storage policies are owner-only for mutations. Public buckets handle reads.
drop policy if exists "Owner can upload portfolio images" on storage.objects;
drop policy if exists "Owner can update portfolio images" on storage.objects;
drop policy if exists "Owner can delete portfolio images" on storage.objects;
drop policy if exists "Owner can upload CAD models" on storage.objects;
drop policy if exists "Owner can update CAD models" on storage.objects;
drop policy if exists "Owner can delete CAD models" on storage.objects;

create policy "Owner can upload portfolio images"
on storage.objects for insert
to authenticated
with check (bucket_id = 'cad-portfolio' and public.is_owner());

create policy "Owner can update portfolio images"
on storage.objects for update
to authenticated
using (bucket_id = 'cad-portfolio' and public.is_owner())
with check (bucket_id = 'cad-portfolio' and public.is_owner());

create policy "Owner can delete portfolio images"
on storage.objects for delete
to authenticated
using (bucket_id = 'cad-portfolio' and public.is_owner());

create policy "Owner can upload CAD models"
on storage.objects for insert
to authenticated
with check (bucket_id = 'cad-models' and public.is_owner());

create policy "Owner can update CAD models"
on storage.objects for update
to authenticated
using (bucket_id = 'cad-models' and public.is_owner())
with check (bucket_id = 'cad-models' and public.is_owner());

create policy "Owner can delete CAD models"
on storage.objects for delete
to authenticated
using (bucket_id = 'cad-models' and public.is_owner());

-- No fabricated projects, testimonials, clients, statistics, or software entries are seeded.
-- The public UI uses only the confirmed AutoCAD fallback until the owner publishes a software list.

-- IMPORTANT: after creating your owner user in Supabase Authentication, run:
-- insert into public.owner_profiles (user_id) values ('YOUR-AUTH-USER-UUID')
-- on conflict (user_id) do nothing;
