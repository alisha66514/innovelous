# Innovelous Technology — CAD Portfolio

Production-ready single-page portfolio for `autocad.innovelous.com`, built as a specialist extension of `https://innovelous.com/`.

## Design / public experience

- Premium black + charcoal visual system with restrained Innovelous purple accents
- Compact single-page structure: Header → Hero → Projects → Software & Expertise → Contact
- Supplied Innovelous logo links to the main website
- Hero uses the supplied **real GLB model** as the primary visual on the right
- Desktop: concise copy left / interactive model right
- Mobile: copy stacks above the model and the viewer remains touch-interactive
- Model rotate, zoom, auto-rotate, pause/resume, reset, fullscreen, loading and error states retained
- Reduced-motion support disables automatic motion where appropriate
- No fabricated testimonials, client logos, statistics, or project work

## 3D hero model orientation

`assets/models/innovelous-cad-model-upright.glb` is the corrected web copy of the uploaded model.

The original assembly was authored Z-up. The corrected GLB stores the axis conversion in the model root for glTF/model-viewer Y-up coordinates. Its base is grounded at Y=0 and centered horizontally. The hero viewer does **not** use a camera trick to make a sideways model look upright.

Do not replace the hero GLB with the pre-fix model. The reset control intentionally changes only camera orbit/target and keeps the corrected model orientation intact.

## Project portfolio

Published projects are loaded from Supabase and support:

- Cover + up to 6 project images
- Title, category, short overview and optional date
- Software-used tags
- Optional project-specific `.glb` file
- Image gallery in the public detail view
- Interactive 3D view when a project GLB is available
- Published/draft state
- Reordering
- Owner add / edit / delete

When no projects are published, the public site shows a neutral “project showcase in progress” state rather than fake work.

## Software & Expertise

The software section is owner-editable. Do not add tools or expertise the team does not actually use.

Until a Supabase software list is published, the site displays only **AutoCAD**, which is confirmed by the purpose/content of this portfolio. Once you publish software entries in the owner panel, they replace the fallback.

## Supabase setup / migration

The included `supabase-schema.sql` is designed to work for a fresh install **or as an upgrade from the earlier portfolio build**.

1. Create/open the Supabase project.
2. Run the latest `supabase-schema.sql` in **SQL Editor**.
3. Create the owner account in **Authentication → Users**.
4. Copy that user's UUID and run:

```sql
insert into public.owner_profiles (user_id)
values ('YOUR-AUTH-USER-UUID')
on conflict (user_id) do nothing;
```

5. In **Project Settings → API**, copy the project URL and public anon key into `config.js`.
6. Never expose a Supabase `service_role` key in browser code.

The schema includes:

- `cad_projects` metadata table with RLS
- `cad_software` editable software/expertise table with RLS
- `cad-portfolio` public image bucket (owner-only mutations, max 8 MB/image)
- `cad-models` public GLB bucket (owner-only mutations, max 50 MB/model)

## Owner access

The owner panel is intentionally absent from public navigation.

Use either:

- `https://autocad.innovelous.com/?owner=1`
- **Alt/Option + Shift + A**

The owner panel supports project and software management. Authentication is enforced by Supabase Auth + RLS; hiding the entry point is only a presentation choice.

## Contact destination

The public “Discuss Your Project” CTA points to:

`https://innovelous.com/`

The footer also includes the requested official links:

- `https://innovelous.com/`
- `https://www.linkedin.com/company/innovelous-technology/posts/?feedView=all`

If the main site's contact anchor changes, update `contactHref` in `config.js`.

## Local preview

Serve the folder over HTTP rather than double-clicking `index.html`:

```bash
python -m http.server 8080
```

Then open:

`http://localhost:8080`

VS Code Live Server works as well; make sure this folder itself is the server root.

## Deploy to `autocad.innovelous.com`

Deploy the entire folder to your static host (Vercel, Netlify, Cloudflare Pages, etc.) and attach the `autocad.innovelous.com` custom domain.

The supplied `.glb` is cached long-term by `_headers` / `vercel.json`. For the best production experience, serve static assets over HTTP/2 or HTTP/3 with byte-range support.

## Demo project cards
This build includes six clearly labeled SAMPLE PROJECT cards so the portfolio section has a finished visual presentation before real project content is added. When Supabase contains published projects, real database projects automatically replace the sample set. The sample images are stored in `assets/projects/`.


## WhatsApp and tools section

The public contact UI includes WhatsApp at **+92 332 9250936** using `https://wa.me/923329250936`. You can change the destination later in `config.js` via `whatsappHref`.

The **Tools behind the work** section is generated from the `software_used` values on published projects. It therefore shows only software actually assigned to visible CAD work, with an optional note/initials sourced from the editable software metadata in the owner dashboard.
