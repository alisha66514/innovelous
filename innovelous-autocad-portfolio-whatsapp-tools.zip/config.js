/**
 * Public client configuration.
 * Supabase anon keys are designed to be exposed in browser apps; security is enforced by RLS.
 * NEVER place a Supabase service-role key in this file.
 */
window.AUTOCAD_PORTFOLIO_CONFIG = {
  supabaseUrl: "",
  supabaseAnonKey: "",
  contactHref: "https://innovelous.com/",
  whatsappHref: "https://wa.me/923329250936",
  modelPath: "./assets/models/innovelous-cad-model-upright.glb",
  maxUploadBytes: 8 * 1024 * 1024,
  maxModelUploadBytes: 50 * 1024 * 1024,
};
