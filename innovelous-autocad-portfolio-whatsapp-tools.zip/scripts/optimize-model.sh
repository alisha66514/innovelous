#!/usr/bin/env bash
set -euo pipefail
INPUT="${1:-assets/models/innovelous-cad-model-upright.glb}"
OUTPUT="${2:-assets/models/innovelous-cad-model.meshopt.glb}"
npx @gltf-transform/cli optimize "$INPUT" "$OUTPUT" --compress meshopt
printf '\nOptimized model written to %s\n' "$OUTPUT"
